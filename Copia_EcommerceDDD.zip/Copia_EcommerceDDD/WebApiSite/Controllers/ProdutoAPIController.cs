﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApplicationApp.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace WebApiSite.Controllers
{
    [Authorize]
    public class ProdutoAPIController : Controller
    {

        public readonly InterfaceProductApp _InterfaceProductApp;


        public ProdutoAPIController(InterfaceProductApp InterfaceProductApp)
        {
            _InterfaceProductApp = InterfaceProductApp;
      
        }


      

    }
}
